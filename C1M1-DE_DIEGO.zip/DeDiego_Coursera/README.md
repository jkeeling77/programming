Author: Ximena de Diego
Project: Assignment 1 of Introduction Embedded Systems
Analyize an array of unsigned char data items and report analytics on the maximum, minimum, mean, and median of the data set. Additionally, order the array from large to small value.
