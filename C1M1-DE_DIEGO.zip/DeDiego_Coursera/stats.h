/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file stats.h 
 * @brief Array statistics declaration
 *
 *	Assignment 1 of Introduction Embedded Systems
 *	Analyize an array of unsigned char data items and report analytics on
 *	the maximum, minimum, mean, and median of the data set. Additionally,
 *	order the array from large to small value.
 *
 * @author Ximena de Diego
 * @date 24/04/2023
 *
 **/
#ifndef __STATS_H__
#define __STATS_H__

/**
 * @brief Array print values
 *
 * Function to print the values of an array
 *
 * @param parray A unsigned char pointer to an n-element data array
 * @param array_size An unsigned integer as the size of the array
 *
 * @return None
 */
void print_array (unsigned char *parray, unsigned int array_size);

/**
 * @brief Maximum value
 *
 * Function to calculate the maximum value of an array
 *
 * @param parray A unsigned char pointer to an n-element data array
 * @param array_size An unsigned integer as the size of the array
 *
 * @return An unsigned char maximum value
 */
unsigned char find_maximum (unsigned char *parray, unsigned int array_size);

/**
 * @brief Minimum value
 *
 * Function to calculate the minimum value of an array
 *
 * @param parray A unsigned char pointer to an n-element data array
 * @param array_size An unsigned integer as the size of the array
 *
 * @return An unsigned char minimum value
 */
unsigned char find_minimum (unsigned char *parray, unsigned int array_size);

/**
 * @brief Mean value
 *
 * Function to calculate the mean value of an array
 *
 * @param parray A unsigned char pointer to an n-element data array
 * @param array_size An unsigned integer as the size of the array
 *
 * @return An unsigned char mean value
 */
unsigned char find_mean (unsigned char *parray, unsigned int array_size);

/**
 * @brief Short array
 *
 * Function to short an array is descending order
 *
 * @param parray A unsigned char pointer to an n-element data array
 * @param array_size An unsigned integer as the size of the array
 *
 * @return None
 */
void sort_array (unsigned char *parray, unsigned int array_size);

/**
 * @brief Mean value
 *
 * Function to calculate the median value of an array
 * A median is the value present at the center of a  sorted array list.
 * To calculate the median first we need to  sort the list in ascending
 * or descending order.  If the number of elements are even , then the median 
 * will the average of two numbers in the middle. But the number is odd then the
 * middle element of the array after sorting will be considered as the median."
 *
 * @param parray A unsigned char pointer to an n-element data array
 * @param array_size An unsigned integer as the size of the array
 *
 * @return An unsigned char median value
 */
unsigned char find_median (unsigned char *parray, unsigned int array_size);
 
/**
 * @brief Array statistics
 *
 * Function to print the statistics of an array including minimum, maximum, mean
 * and median
 *
 * @param parray A unsigned char pointer to an n-element data array
 * @param array_size An unsigned integer as the size of the array
 *
 * @return None
 */
void print_statistics (unsigned char *parray, unsigned int array_size);


#endif /* __STATS_H__ */
