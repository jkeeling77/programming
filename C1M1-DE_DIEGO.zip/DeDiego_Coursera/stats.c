/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file stats.c
 * @brief Array statistics
 *
 *	Assignment 1 of Introduction Embedded Systems
 *	Analyize an array of unsigned char data items and report analytics on
 *	the maximum, minimum, mean, and median of the data set. Additionally,
 *	order the array from large
 *	to small value.
 *
 * @author Ximena de Diego
 * @date 24/04/2023
 *
 */


#include <stdio.h>
#include "stats.h"

/* Size of the Data Set */
#define SIZE (40)

void main()
{
	unsigned char test[SIZE] = { 34, 201, 190, 154,   8, 194,   2,   6,                                         114, 88,   45,  76, 123,  87,  25,  23,
                                    200, 122, 150, 90,   92,  87, 177, 244,
                                    201,   6,  12,  60,   8,   2,   5,  67,
                                      7,  87, 250, 230,  99,   3, 100,  90};

	/* Print the array */
	print_array(test, SIZE);

	/* Print the statistics of the array */
	print_statistics(test, SIZE);
}

/* Function to print the values of an array */
void print_array (unsigned char *parray, unsigned int array_size)
{
	int i = 0; /* Variable to traverse the array */
	
	/* Print the array */	
	printf("Array = {");
	
	/* Traverse the array in order to print each value */	
	for (i = 0; i < array_size ; i++)
	{
		if (i == array_size - 1)
			printf("%d}\n\n", parray[i]); /* Print the last value
						       different */
		else
			printf("%d, ", parray[i]);
	}
}

/* Function to calculate the maximum value of an array */
unsigned char find_maximum (unsigned char *parray, unsigned int array_size)
{
	int i = 0; /* Variable to traverse the array */
	unsigned char max = parray[0]; /* Variable to store the maximum value */
	
	/* Traverse the array in order to find the maximum value */
	for (i = 1; i < array_size ; i++)
	{
		if (max < parray[i])
			max = parray[i];
	}
					
	/* Return the maximum value */
	return max;
}

/* Function to calculate the minimum value of an array */
unsigned char find_minimum (unsigned char *parray, unsigned int array_size)
{
	int i = 0; /* Variable to traverse the array */
	unsigned char min = parray[0]; /* Variable to store the minimum value */
	
	/* Traverse the array in order to find the maximum value */
	for (i = 1; i < array_size ; i++)
	{
		if (min > parray[i])
			min = parray[i];
	}
				
	/* Return the maximum value */
	return min;
}

/* Function to calculate the mean of an array */
unsigned char find_mean (unsigned char *parray, unsigned int array_size)
{
	int i = 0; /* Variable to traverse the array */
	unsigned char mean = 0; /* Variable to store the mean value */
	int sum = 0; /* Variable to store the sum of the values */
	
	/* Traverse the array in order to find the sum all the values of the
	 * array */	
	for (i = 0; i < array_size ; i++)
	{
		sum = parray[i] + sum;
	}

	/* Calculate the mean value */
	mean = sum / array_size;
				
	/* Return the mean value */	
	return mean;
}

/* Function to short an array is descending order */
void sort_array (unsigned char *parray, unsigned int array_size)
{
	/* Declare local variables for shorting the array */
	int i = 0, j = 0, temp = 0;
			
	/* Traverse the array in order to sort the values */
	for (i = 0; i < array_size; i++)
	{
		for (j = i + 1; j < array_size; j++)
		{
			if (parray[i] < parray[j])
			{
				temp = parray[j];
				parray[j] = parray[i];
				parray[i] = temp;
			}
		}
	}
}

/* Function to calculate the median of an array */
unsigned char find_median (unsigned char *parray, unsigned int array_size)
{
	unsigned char median = 0; /* Variable to store the median value */
	
	/* Sort array in order to find the median value */
	sort_array(parray, array_size);

	/* If the number of elements are even */
	if (array_size%2 == 0)
		median = (parray[(array_size - 1)/2] + parray[array_size/2])/2;
	else /* If the number of elements are odd */
		median = parray[array_size/2];
		
	return median;
}

/*  Function to print the statistics of an array including minimum, maximum, mean, and median */
void print_statistics (unsigned char *parray, unsigned int array_size)
{
	unsigned char min, max, mean, median; /* Variables to store the printed
						 values */
			
	printf("The statistics of the array are:\n");
					
	min = find_minimum(parray, array_size);
	printf("  - Minimum: %d\n", min);
			
	max = find_maximum(parray, array_size);
	printf("  - Maximum: %d\n", max);

	mean = find_mean(parray, array_size);
	printf("  - Mean: %d\n", mean);
			
	median = find_median(parray, array_size);
	printf("  - Median: %d\n", median);
						
	printf("The sorted array is:\n");
	print_array(parray, array_size);
}
