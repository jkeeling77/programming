/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file stats.h
 * @brief function declarations and documentation for stats.c
 *
 * This file contains the function declarations for various statistical operations
 * to be performed on an array of items.  These include mean, median, minimum, and 
 * maximum.
 *
 * @author Chris Schultz
 * @date editted April 19, 2023
 *
 */
#ifndef __STATS_H__
#define __STATS_H__

/* Add Your Declarations and Function Comments here */ 

/**
 * @brief A function that prints the statistics of an array
 * 
 * This function will print the calculated statistics of an array.  These include
 * minimum, maximum, mean, and meadian.
 *
 * @param array pointer to the array with the chars to be worked on
 * @param length the length of the array
 * 
 * There is no return value.  Results are output to standard output.
 */
void print_statistics(unsigned char *array, unsigned int length);

/**
 * @brief A function to pretty print your array at 8 elements wide
 * 
 * @param array pointer to the array to be printed
 * @param length the length of the array
 * 
 * There is no return value.  Results are output to standard output.
*/
void print_array(unsigned char *array, unsigned int length);

/**
 * @brief Given an array of data and a length, return the median value
 * 
 * This function returns the middle value of a sorted array.  If the length
 * of the array is even, the return value is the result of the average of the
 * two middle values divided by (int) 2
 * 
 * @param array pointer to the array with the chars to be worked on
 * @param length the length of the array
 * 
 * @return The integer value for the median
*/
unsigned char find_median(unsigned char *array, unsigned int length);

/**
 * @brief Given an array of chars and a length, return the mean
 * 
 * This function returns the mean of the values in an array.  The value is
 * derived using integer division, so the result of the sum / length
 * would be the floor or the result.
 * 
 * @param array point to the array with the chars to be worked on
 * @param length the length of the array
 * 
 * @return the integer value for the mean
*/
unsigned char find_mean(unsigned char *array, unsigned int length);

/**
 * @brief Given an array of chars and a length, return the maximum value
 * 
 * This function returns the maximum value from a list of chars.  This function does
 * not assume the list to be sorted.
 * 
 * @param array pointer to the array with the chars to be worked on
 * @param length the length of the array
 * 
 * @return the largest char from the array
*/
unsigned char find_maximum(unsigned char *array, unsigned int length);

/**
 * @brief Given an array of chars and a length, return the minumum value
 * 
 * This function returns the minimum value from a list of chars.  This function does
 * not assume the list to be sorted.
 * 
 * @param array array with the chars to be worked on
 * @param the length of the array
 * 
 * @return the smallest char from the array
*/
unsigned char find_minumum(unsigned char *array, unsigned int length);

/**
 * @brief Given an array of chars, sort the array from largest to smallest
 * 
 * this sort uses an insertion sort algorithm.  Since many of the statistical
 * functions rely on a sorted list, this function could be called a multiple of
 * times.  The insertion sort is linear after the first call.  Quicksort could also
 * have been used.
 * 
 * @param array point to the array with the chars to be sorted
 * @param the length of the array
 * 
 * There is no return value, the sort is done in place on the memory location
 * pointed to by the value array.
*/
void sort_array(unsigned char *array, unsigned int length);

#endif /* __STATS_H__ */
