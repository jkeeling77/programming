# Introduction to Embedded Systems

Coursera Class #1 -- Assessment #1

## Copyright (C) 2023 - Christian Schultz

The work within this directory is done by Christian Schultz to satisfy the requirements 
for the Coursera class 'Introduction to Embedded Systems.'  
Certain materials are subject to the following copyright.

### Original Copyright
Copyright (C) 2017 by Alex Fosdick - University of Colorado
Redistribution, modification or use of this software in source or binary
forms is permitted as long as the files maintain this copyright. Users are 
permitted to modify this and use it to learn about the field of embedded
software. Alex Fosdick and the University of Colorado are not liable for any
misuse of this material.