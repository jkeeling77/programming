/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file stats.c 
 * @brief finds statistical values for the list given in main
 *
 * This file implements the functions in stats.h.  The main function provides
 * a simple test for these functions.
 *
 * @author Chris Schultz
 * @date editted April 19, 2023
 *
 */



#include <stdio.h>
#include "stats.h"

/* Size of the Data Set */
#define SIZE (40)

void main() {

  unsigned char test[SIZE] = { 34, 201, 190, 154,   8, 194,   2,   6,
                              114, 88,   45,  76, 123,  87,  25,  23,
                              200, 122, 150, 90,   92,  87, 177, 244,
                              201,   6,  12,  60,   8,   2,   5,  67,
                                7,  87, 250, 230,  99,   3, 100,  90};

  /* Other Variable Declarations Go Here */
  // check for size of array being correct
  int size = sizeof(test) / sizeof(char);
  if (size != SIZE) {
    printf("Problems with the array size\n");
  }
  

  /* Programming for remainder of main go here */
  print_statistics(test, SIZE);
}

/* Statistics and Printing Functions Go Here */

void print_statistics(unsigned char *array, unsigned int length) {
  // indentations are for readability purposes
  printf("Original Array: \n");
    print_array(array, length);
  printf("Sorted Array: \n");
    sort_array(array, length);
    print_array(array, length);
  printf("Statistics: \n");
    printf("%10s: %d\n", "Minimum", find_minumum(array, length));
    printf("%10s: %d\n", "Maximum", find_maximum(array, length));
    printf("%10s: %d\n", "Mean", find_mean(array, length));
    printf("%10s: %d\n", "Median", find_median(array, length));

}

void print_array(unsigned char *array, unsigned int length) {
  printf("[\n");
  for (int i = 0; i < length; ) {                   /* don't forget to increment i */
    printf("  ");
    for (int col = 0; col < 8  && i < length; col++) {
      printf("%5d ", array[i++]);                   /* incremmented i */
    }
    printf("\n");
  }
  printf("]\n");

}

unsigned char find_median(unsigned char *array, unsigned int length) {
  sort_array(array, length);
  int halfLength = length / 2;                /* store away to prevent too many divisions */
  if (length % 2 != 0) {                      /* there is a true middle */
    return array[halfLength + 1];
  }             
  else {                                      /* find the integer between the two middles */
    int a = array[halfLength];
    int b = array[halfLength + 1];
    return (a + b) / 2;
  }
}

unsigned char find_mean(unsigned char *array, unsigned int length) {
  int sum = 0;
  for (int i = 0; i < length; i++)
  {
    sum += array[i];
  }
  return sum / length;
}

unsigned char find_maximum(unsigned char *array, unsigned int length) {
  sort_array(array, length);
  return array[0];
}

unsigned char find_minumum(unsigned char *array, unsigned int length) {
  sort_array(array, length);
  return array[length - 1];
}

void sort_array(unsigned char *array, unsigned int length) {
  for (int i = 1; i < length; i++) {
    // move array[i] backwards towards array[0] as long as it is larger
    int j = i - 1;
    while (j >= 0 && array[j] <= array[j + 1]) {        /* while j is not first and current > previous */
      char temp = array[j + 1];
      array[j + 1] = array[j];
      array[j] = temp;
      j--;
    }
  }

}


/* Add other Implementation File Code Here */


