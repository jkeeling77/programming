/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file   stats.h
 * @brief  Header file for stats.c
 *
 * Header file for Week 1 Application Assignment
 *
 * @author Johannes Kunst
 * @date   26.04.2023
 *
 */
#ifndef __STATS_H__
#define __STATS_H__

/* Add Your Declarations and Function Comments here */ 

/**
 * @brief Output of the array statistics to the screen
 * 
 * Prints Minimum value, Maximum value, Mean value, Medain value and
 * sorted array on stdout
 * 
 * @param   Pointer on unsigned char array
 * @param   Size of unsigned char array
 * @return  nothing
 */
void print_statistics(unsigned char *input_array, unsigned char array_size);

/**
 * @brief Output of the array to the screen
 * 
 * Prints array with index and value on stdout. Every 8th element a line feed
 * is inserted 
 * 
 * @param   Pointer on unsigned char array
 * @param   Size of unsigned char array
 * @return  nothing
 */
void print_array(unsigned char *input_array, unsigned char array_size);

/**
 * @brief Calculation of the median value of the array elements
 * 
 * Calculation of the median value of the array elements according to
 * https://en.wikipedia.org/wiki/Median
 * ATTENTION: This function uses sort_array that changes the input_array
 * After executng this function the input_array is sorted and not the original 
 * any more
 * 
 * @param  Pointer on unsigned char array
 * @param  Size of unsigned char array
 * @return result as unsigned char (rounded to integer value)
 */
unsigned char find_median(unsigned char *input_array, unsigned char array_size);

/**
 * @brief Calculation of the mean value of the array elements
 * 
 * Calculation of the mean value of the array elements
 * 
 * @param  Pointer on unsigned char array
 * @param  Size of unsigned char array
 * @return result as unsigned char (rounded to integer value)
 */
unsigned char find_mean(unsigned char *input_array, unsigned char array_size);

/**
 * @brief Calculation of the maximum value of the array elements
 * 
 * Calculation of the maximum value of the array elements
 * 
 * @param  Pointer on unsigned char array
 * @param  Size of unsigned char array
 * @return result as unsigned char (rounded to integer value)
 */
unsigned char find_maximum(unsigned char *input_array, unsigned char array_size);

/**
 * @brief Calculation of the minimum value of the array elements
 * 
 * Calculation of the minimum value of the array elements
 * 
 * @param  Pointer on unsigned char array
 * @param  Size of unsigned char array
 * @return result as unsigned char
 */
unsigned char find_minimum(unsigned char *input_array, unsigned char array_size);

/**
 * @brief Sorting of the array elements
 * 
 * Sorting of the array elements according to https://en.wikipedia.org/wiki/Bubble_sort
 * ATTENTION: This function changes the input_array
 * After executng this function the input_array is sorted and not the original 
 * any more
 * @param  Pointer on unsigned char array
 * @param  Size of unsigned char array
 * @return nothing because input array is changed (only pointers are handed over)
 */
void sort_array(unsigned char *input_array, unsigned char array_size);


#endif /* __STATS_H__ */
