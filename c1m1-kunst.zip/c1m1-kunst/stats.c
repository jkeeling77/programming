/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material.
 *
 *****************************************************************************/
/**
 * @file   stats.c 
 * @brief  Assignmet 1st week of Coursera course
 *         "Introduction Embedded Systems Software and Development Environments"
 *
 * The stats.c implementation file contains:
 *     1. main() - The main entry point for your program
 *     2. print_statistics() - A function that prints the statistics of an array
 *        including minimum, maximum, mean, and median.
 *     3. print_array() - Given an array of data and a length, prints the array
 *        to the screen
 *     4. find_median() - Given an array of data and a length, returns the
 *        median value
 *     5. find_mean() - Given an array of data and a length, returns the mean
 *     6. find_maximum() - Given an array of data and a length,
 *        returns the maximum
 *     7. find_minimum() - Given an array of data and a length,
 *        returns the minimum
 *     8. sort_array() - Given an array of data and a length, sorts the array from
 *        largest to smallest. (The zeroth Element should be the largest value,
 *        and the last element (n-1) should be the smallest value. )
 *
 * @author Johannes Kunst
 * @date   26.04.2023
 *
 */

#include <stdio.h>
#include "stats.h"

/* Size of the Data Set */
#define SIZE (40)

void main() {

  unsigned char test[SIZE] = { 34, 201, 190, 154,   8, 194,   2,   6,
                              114, 88,   45,  76, 123,  87,  25,  23,
                              200, 122, 150, 90,   92,  87, 177, 244,
                              201,   6,  12,  60,   8,   2,   5,  67,
                                7,  87, 250, 230,  99,   3, 100,  90};

  /* Other Variable Declarations Go Here */
  /* Statistics and Printing Functions Go Here */
  printf("Input array (index: value, ...) :");
  print_array(test,SIZE);

  print_statistics(test,SIZE);

}

/* Add other Implementation File Code Here */
void print_statistics(unsigned char *input_array, unsigned char array_size)
{
  printf("\n");
  printf("Minimum value         : %3u\n", find_minimum(input_array,array_size));
  printf("Maximum value         : %3u\n", find_maximum(input_array,array_size));
  printf("Mean value            : %3u\n", find_mean(input_array,array_size));
  printf("Medain value          : %3u\n", find_median(input_array,array_size));
  printf("\n");

  printf("Sorted array (index: value, ...) :");
  /* Median calculation has changed the original array to a sorted array
   * so that input_array is sorted array here */
  print_array(input_array, array_size);
}


void print_array(unsigned char *input_array, unsigned char array_size)
{
  int i;
  for (i=0; i<array_size;i++)
    {
      if (i % 8 == 0)
        /* after 8 values newline */
        printf("\n");
      if (i == (array_size - 1))
        /* last array value printed without comma and spaces at the end */
        printf("%2i: %3u",i,input_array[i]);
      else
        printf("%2i: %3u,   ",i,input_array[i]);
    }
  printf("\n");
}


unsigned char find_median(unsigned char *input_array, unsigned char array_size)
{ // see https://en.wikipedia.org/wiki/Median
  sort_array(input_array, array_size);
  if (array_size % 2 == 0)
    /* Even amount of elements
     * It was requested that functions should return rounded integer values.
     * Therefore type cast on unsigned char for non interger results
     * C counts array beginning with zero, thus index_c=index_wiki-1 */
    return (unsigned char) ((input_array[(int) (array_size/2-1)] + input_array[(int) (array_size/2+1-1)])/2);
  else
    // Odd amount of elements
    return input_array[(int) ((array_size+1)/2-1)];
}


unsigned char find_mean(unsigned char *input_array, unsigned char array_size)
{
  unsigned char i;
  int m;
  m=0;
  for (i=0; i<array_size;i++)
    m+=input_array[i];
  /* It was requested that functions should return rounded integer values.
   * Therefore type cast on unsigned char for non interger results  */
  return (unsigned char) (m/array_size);
}


unsigned char find_maximum(unsigned char *input_array, unsigned char array_size)
{
  unsigned char i,m;
  m=0;
  for (i=0; i<array_size;i++)
    if (input_array[i] > m)
      m=input_array[i];
  return m;
}


unsigned char find_minimum(unsigned char *input_array, unsigned char array_size)
{
  unsigned char i,m;
  m=255;
  for (i=0; i<array_size;i++)
    if (input_array[i] < m)
      m=input_array[i];
  return m;
}


void sort_array(unsigned char *input_array, unsigned char array_size)
{
  // using Bubble sort algorithm https://en.wikipedia.org/wiki/Bubble_sort
  unsigned char m,swapped_flag,tmp;
  do {
    swapped_flag=0;
    for (m=0; m<array_size-1;m++)
      if (input_array[m] < input_array[m+1])
        {
          tmp=input_array[m];
          input_array[m]=input_array[m+1];
          input_array[m+1]=tmp;
          swapped_flag=1;
        }
  }
  while (swapped_flag==1);
  return;
}

